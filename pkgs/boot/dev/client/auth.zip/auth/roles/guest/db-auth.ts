import { DBAuth } from 'server-web'

export default (({}) => {
  return true // allow all access
}) as DBAuth
