export const GlobalData = {}
