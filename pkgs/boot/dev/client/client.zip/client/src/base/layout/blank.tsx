import { layout } from 'web-init'

export default layout({
  component: ({ children }) => {
    return <>{children}</>
  },
})
