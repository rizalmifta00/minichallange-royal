import { page } from 'web-init'

export default page({
  url: '/',
  component: ({}) => {
    return <div>Halo</div>
  }
})