import type * as dbs from 'dbs'

declare global {
  
}
  