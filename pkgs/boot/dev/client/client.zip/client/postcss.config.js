const path = require('path')

module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
